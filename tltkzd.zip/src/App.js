import "./styles.css";
import Styles from "./components/Styles";
import ToastExample from "./components/ChakraUi"


export default function App() {
  return (
    <div className="App">

      
       <ToastExample />
    </div>
  );
}
